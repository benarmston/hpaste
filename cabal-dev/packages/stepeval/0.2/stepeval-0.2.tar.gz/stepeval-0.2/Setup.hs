module Main (main) where
import Distribution.Simple
main = defaultMain
